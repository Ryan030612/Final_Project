import os
import numpy as np
from sklearn.preprocessing import MinMaxScaler
import scipy.io as scio
import time
from mdpc_original import mdpc_plus
from mdpc_umap import mdpc_plus_umap
os.environ['OMP_NESTED'] = 'FALSE'
from evaluation import compute_score
import sys
import warnings
import matplotlib.pyplot as plt
os.environ["OMP_NESTED"] = "FALSE"
os.environ["OMP_DISPLAY_ENV"] = "FALSE"
os.environ["OMP_WARNINGS"] = "FALSE"
# 过滤特定警告
warnings.filterwarnings("ignore", 
                       message="n_jobs value -1 overridden to 1 by setting random_state. Use no seed for parallelism.")

def process_dataset(mat_path, k=None):
    """处理单个数据集的函数(已添加完整指标输出)"""
    # 加载数据
    data1 = scio.loadmat(mat_path)
    data_keys = list(data1.keys())
    data = data1[data_keys[-2]].astype(np.float32)
    y_true = np.ravel(data1[data_keys[-1]])
    n, d = data.shape
    
    # 数据预处理
    scaler = MinMaxScaler(feature_range=(0, 1))
    data = scaler.fit_transform(data)
    n_clusters = len(np.unique(y_true))
    
    dimensions = np.arange(2, 11)  # 维度从2到10
    acc_scores = []  # 准确率
    ari_scores = []  # 调整兰德指数
    nmi_scores = []  # 标准化互信息

    # 添加UMAP降维选择
    if d >= 20 and d <= 50:  # 20-50维数据集
        dimensions = np.arange(2, 11)
        for d1 in range(2, 11):
            labels, centers, runtime = mdpc_plus_umap(data, k=None, num_cluster=n_clusters, dim=d1)
            
            ARI, NMI, ACC = compute_score(labels, y_true)  # score
           
            acc_scores.append(ACC)  # 准确率
            ari_scores.append(ARI) # 调整兰德指数
            nmi_scores.append(NMI) # 标准化互信息

            print('d: {d:.2f}\nARI: {a:.2f}\nNMI: {b:.2f}\nACC: {c:.2f}'.format(d=d1, a=ARI, b=NMI, c=ACC))
    elif d > 50:  # 50维以上数据集
        dimensions = np.arange(2, 21)
        for d1 in range(2, 21):

            labels, centers, runtime = mdpc_plus_umap(data, k=None, num_cluster=n_clusters, dim=d1)
            
            ARI, NMI, ACC = compute_score(labels, y_true)  # score
            acc_scores.append(ACC)  # 准确率
            ari_scores.append(ARI) # 调整兰德指数
            nmi_scores.append(NMI)
            
            print('d: {d:.2f}\nARI: {a:.2f}\nNMI: {b:.2f}\nACC: {c:.2f}'.format(d=d1, a=ARI, b=NMI, c=ACC))
   
   
        # 创建图形
    plt.figure(figsize=(10, 6))

    # 绘制三条折线
    plt.plot(dimensions, acc_scores, marker='o', label='ACC', linewidth=2)
    plt.plot(dimensions, ari_scores, marker='s', label='ARI', linewidth=2)
    plt.plot(dimensions, nmi_scores, marker='^', label='NMI', linewidth=2)

    # 添加标题和标签
    plt.title('Algorithm Robustness of semeionEW', fontsize=16)
    plt.xlabel('Number of Dimensions', fontsize=14)
    plt.ylabel('Score', fontsize=14)
   

    # 设置x轴刻度为整数
    #plt.xticks(np.arange(2, 11))
    plt.ylim(0, 100)


    plt.xticks(np.arange(2, 21,2))

    # 添加网格线
    plt.grid(True, linestyle='--', alpha=0.6)

    # 添加图例
    plt.legend(fontsize=14)

    # 调整布局
    plt.tight_layout()
    plt.savefig("robust_semeionEW.svg")

    # 显示图形
    plt.show()

            
if __name__ == "__main__":
    mat_path = './real_all/semeionEW.mat'
    
    process_dataset(mat_path, k=None)